let version = "0.89.170922 "^"September 2017"
let default_path = "/usr/local/lib/phox"
let delim = ':'
